import React, { useEffect, useState } from 'react'
import ItemDetail from '../ItemDetail/ItemDetail'

export default function ItemDetailContainer() {
    const [loading, setLoading] = useState(false)
    const [guitars, setGuitars] = useState([])

    useEffect(() => {
        setLoading(true)
        fetch('https://api.mercadolibre.com/sites/MLA/search?q=guitarras')
        .then((res) => (res.json()))
        .then((data) => setGuitars(data.results))
        .catch((err) => console.error(err))
        .finally(()=>setLoading(false))
    },[])
    
    return (
            <div>
                {loading} ? <h3>Loading...</h3>:<ItemDetail guitars={guitars}/>
                
            </div>
        );
  }