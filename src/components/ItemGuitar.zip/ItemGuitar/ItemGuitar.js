import React from "react";
import { Card, Button } from "react-bootstrap";

const ItemGuitar = ({guitar}) => {
    return(
            <div class="col">
               <h1>{guitar.title}</h1>
        </div>
    );
}

export default ItemGuitar