import React from 'react'
import ItemGuitar from "../ItemGuitar/ItemGuitar"

export default function ItemDetail(guitars) {
    
  return (
      <div className='d-flex justify-content-center'>
          {guitars.map((guitar) => (
          <ItemGuitar guitar={guitar} key={guitar.id}/>
          )
      )}
      </div>
    );
  }